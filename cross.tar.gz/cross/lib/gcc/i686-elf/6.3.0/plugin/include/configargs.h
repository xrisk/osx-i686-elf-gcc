/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-6.3.0/configure --target=i686-elf --prefix=/Users/rishav/opt/cross --disable-nls --enable-languages=c,c++ --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "pentiumpro" } };
